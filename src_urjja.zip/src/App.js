import React from "react";
 import * as Components from './components';
 import Signin from "./signin";

 function App() {
    
      return(
        <Signin/>
      );
 }

 export default App;