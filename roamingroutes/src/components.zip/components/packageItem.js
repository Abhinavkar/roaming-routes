import "./packageItem.css";
import { useNavigate } from "react-router-dom";

const PackageItem = ({onclick,packages}) => {
    const navigate  = useNavigate();
    const getPrice = (location,price) => {
        console.log(location,price);
        navigate("/price", {state: {destination: location, price: price}});
    }
    return (
        <div onClick={onclick}>
        {
            packages.map((item) => {
                return(
                    <div className="packageItem">
                        <img
                            src={item.profile_photo}
                            alt=""
                            className="=siImg"
                        />
                        <div className="sipackage">
                            <div className="siDesc">
                            <h1 className="siTitle">{item.location0}</h1>
                            <span className="siDistance">📌{item.location1}➡️{item.location2}</span>
                            <span className="siTaxiOp">🛫Airport + 🏢Room Taxes</span>

                            <span className="siCancelOp">✅Free Cancellation</span>
                            <span className="siCancelOpSubtitle">🔒lock in this great price today!</span>
                        </div>
                        <div className="siDetails">
                            <div className="siRating">
                                <span style={{padding:"10px"}}>{item.type}</span>
                                <button>8.9⭐</button>
                            </div>
                            <div className="siDetailTexts">
                                <span className="siPrice">Rs.{item.price}/-</span>
                                <br />
                                <button className="siCheckButton" onClick={()=>getPrice(item.location0,item.price)}>Book Package</button>
                                <br />
                            </div>
                        </div>
                    </div>
                </div>
                )
            })
        }
        </div>
        
    );
};

export default PackageItem;